/*
 * Copyright 2006 Marc Wick, geonames.org
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package com.sun.syndication.feed.module.georss;

import com.sun.syndication.feed.synd.SyndEntry;

/**
 * static utility methods for georss.
 * 
 * @author Marc Wick
 * @version $Id: GeoRSSUtils.java,v 1.3 2006/05/08 20:16:46 marcwick Exp $
 * 
 */
public class GeoRSSUtils {

	/**
	 * This convenience method checks whether there is any geoRss Element and
	 * will return it (georss simple or W3GGeo).
	 * 
	 * @param entry
	 *            the element in the feed which might have a georss element
	 * @return a georssmodule or null if none is present
	 */
	public static GeoRSSModule getGeoRSS(SyndEntry entry) {
		GeoRSSModule geoRSSModule = (GeoRSSModule) entry
				.getModule(GeoRSSModule.GEORSS_GEORSS_URI);
		GeoRSSModule w3cGeo = (GeoRSSModule) entry
				.getModule(GeoRSSModule.GEORSS_W3CGEO_URI);
		GeoRSSModule gml = (GeoRSSModule) entry
				.getModule(GeoRSSModule.GEORSS_GML_URI);

		if (geoRSSModule == null && w3cGeo != null) {
			geoRSSModule = w3cGeo;
		} else if (geoRSSModule == null && gml != null) {
			geoRSSModule = gml;
		} else if (geoRSSModule != null && w3cGeo != null) {
			// sanity check
			if (geoRSSModule.getLatitude() != w3cGeo.getLatitude()) {
				throw new Error("latitude of simple and w3c do not match");
			}
			if (geoRSSModule.getLongitude() != w3cGeo.getLongitude()) {
				throw new Error("longitude of simple and w3c do not match");
			}
		}

		return geoRSSModule;
	}

}
