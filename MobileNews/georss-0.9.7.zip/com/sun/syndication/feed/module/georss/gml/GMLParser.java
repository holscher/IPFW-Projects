/*
 * Copyright 2006 Marc Wick, geonames.org
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package com.sun.syndication.feed.module.georss.gml;

import org.jdom.Element;

import com.sun.syndication.feed.module.Module;
import com.sun.syndication.feed.module.georss.GeoRSSModule;
import com.sun.syndication.feed.module.georss.SimpleModuleImpl;
import com.sun.syndication.feed.module.georss.W3CGeoModuleImpl;
import com.sun.syndication.io.ModuleParser;

/**
 * GMLParser is a parser for the GML georss format.
 * 
 * @author Marc Wick
 * @version $Id: GMLParser.java,v 1.1 2006/04/03 18:46:19 marcwick Exp $
 * 
 */
public class GMLParser implements ModuleParser {

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.sun.syndication.io.ModuleParser#getNamespaceUri()
	 */
	public String getNamespaceUri() {
		return GeoRSSModule.GEORSS_GEORSS_URI;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.sun.syndication.io.ModuleParser#parse(org.jdom.Element)
	 */
	public Module parse(Element element) {
		return parseGML(element);
	}

	public static Module parseGML(Element element) {
		GeoRSSModule geoRSSModule = null;

		Element whereElement = element
				.getChild("where", GeoRSSModule.SIMPLE_NS);

		if (whereElement != null) {
			Element pointElement = whereElement.getChild("Point",
					GeoRSSModule.GML_NS);

			Element simple = pointElement.getChild("pos", GeoRSSModule.GML_NS);
			if (simple != null) {
				geoRSSModule = new GMLModuleImpl();
				String coordinates = simple.getText();
				String[] coord = coordinates.split(" ");
				geoRSSModule.setLatitude(Double.parseDouble(coord[0]));
				geoRSSModule.setLongitude(Double.parseDouble(coord[1]));
			}
		}
		return geoRSSModule;
	}

}
