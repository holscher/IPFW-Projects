/*
 * Copyright 2006 Marc Wick, geonames.org
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package com.sun.syndication.feed.module.georss.gml;

import com.sun.syndication.feed.module.ModuleImpl;
import com.sun.syndication.feed.module.georss.GeoRSSModule;

/**
 * GMLModuleImpl is the implementation of the {@link GeoRSSModule} Interface
 * for the gml GeoRSS format.
 * 
 * @author Marc Wick
 * @version $Id: GMLModuleImpl.java,v 1.2 2006/09/01 07:09:18 marcwick Exp $
 * 
 */
public class GMLModuleImpl extends ModuleImpl implements GeoRSSModule {

	private double latitude;

	private double longitude;

	public GMLModuleImpl() {
		super(GeoRSSModule.class, GeoRSSModule.GEORSS_GML_URI);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.georss.rome.GeoRSSModule#setLatitude(double)
	 */
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.georss.rome.GeoRSSModule#setLongitude(double)
	 */
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.georss.rome.GeoRSSModule#getLatitude()
	 */
	public double getLatitude() {
		return latitude;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.georss.rome.GeoRSSModule#getLongitude()
	 */
	public double getLongitude() {
		return longitude;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.sun.syndication.feed.CopyFrom#getInterface()
	 */
	public Class getInterface() {
		return GeoRSSModule.class;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.sun.syndication.feed.CopyFrom#copyFrom(java.lang.Object)
	 */
	public void copyFrom(Object obj) {
		GeoRSSModule geoRSSModule = (GeoRSSModule) obj;
		setLatitude(geoRSSModule.getLatitude());
		setLongitude(geoRSSModule.getLongitude());
	}

}
