/*
 * Copyright 2006 Marc Wick, geonames.org
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package com.sun.syndication.feed.module.georss;

import org.jdom.Namespace;

import com.sun.syndication.feed.module.Module;

/**
 * GeoRSSModule is the main georss interface defining the methods to produce and
 * consume georss elements.
 * 
 * @author Marc Wick
 * @version $Id: GeoRSSModule.java,v 1.6 2007/02/07 08:00:21 marcwick Exp $
 */
public interface GeoRSSModule extends Module {

	/**
	 * namespace URI for georss simple: <i>"http://www.georss.org/georss"</i>
	 */
	public static final String GEORSS_GEORSS_URI = "http://www.georss.org/georss";

	/**
	 * namespace URI for w3c georss :
	 * <i>"http://www.w3.org/2003/01/geo/wgs84_pos#"</i>
	 */
	public static final String GEORSS_W3CGEO_URI = "http://www.w3.org/2003/01/geo/wgs84_pos#";

	/**
	 * namespace URI for GML georss : <i>"http://www.opengis.net/gml"</i>
	 */
	public static final String GEORSS_GML_URI = "http://www.opengis.net/gml";

	/**
	 * Namespace for georss simple :
	 * <i>xmlns:georss="http://www.georss.org/georss"</i>
	 */
	public static final Namespace SIMPLE_NS = Namespace.getNamespace("georss",
			GeoRSSModule.GEORSS_GEORSS_URI);

	/**
	 * 
	 * Namespace for w3c georss :
	 * <i>xmlns:geo="http://www.w3.org/2003/01/geo/wgs84_pos#"</i>
	 */
	public static final Namespace W3CGEO_NS = Namespace.getNamespace("geo",
			GeoRSSModule.GEORSS_W3CGEO_URI);

	/**
	 * 
	 * Namespace for gml georss : <i>xmlns:gml="http://www.opengis.net/gml"</i>
	 */
	public static final Namespace GML_NS = Namespace.getNamespace("gml",
			GeoRSSModule.GEORSS_GML_URI);

	/**
	 * Set latitude of georss element
	 * 
	 * @param latitude
	 *            latitude
	 */
	public void setLatitude(double latitude);

	/**
	 * Set longitude of georss element
	 * 
	 * @param longitude
	 *            longitude
	 */
	public void setLongitude(double longitude);

	/**
	 * returns the latitude
	 * 
	 * @return latitude
	 */
	public double getLatitude();

	/**
	 * returns the longitude
	 * 
	 * @return longitude
	 */
	public double getLongitude();

	static final String SIMPLE_ELEMENTNAME_POINT = "point";

	static final String SIMPLE_ELEMENTNAME_LINE = "line";

	static final String SIMPLE_ELEMENTNAME_POLYGON = "polygon";

}
